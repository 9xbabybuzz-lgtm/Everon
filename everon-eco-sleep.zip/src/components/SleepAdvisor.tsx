import { useState } from "react";
import { Sparkles, Loader2, Bookmark, CheckCircle2, Moon, Compass, ChevronRight } from "lucide-react";
import { ConsultResponse } from "../types";

export function SleepAdvisor() {
  const [name, setName] = useState<string>("");
  const [preferences, setPreferences] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ConsultResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Suggested prompt tags for quick click-and-ask
  const presets = [
    { text: "Phòng hầm bí nóng bức, hay đổ mồ hôi đêm", label: "Hầm bí mùa hè" },
    { text: "Đau mỏi cột sống, thích nệm nằm nâng đỡ vững chãi, thoáng khí", label: "Đau lưng & Bí bách" },
    { text: "Làn da siêu nhạy cảm, dễ dị ứng bám bụi, thích vải cực mềm tơi", label: "Da nhạy cảm" },
    { text: "Khó ngủ, dễ tỉnh giấc giữa đêm, cần không gian thanh tịnh mộc mạc", label: "Khó ngủ & Tĩnh tâm" }
  ];

  const handleConsult = async (customPreference?: string) => {
    const textToSubmit = customPreference || preferences;
    if (!textToSubmit.trim()) {
      setError("Vui lòng nhập chia sẻ của bạn hoặc chọn các gợi ý nhanh bên dưới.");
      return;
    }

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await fetch("/api/consult", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: name || "Quý khách",
          preferences: textToSubmit,
        }),
      });

      const json = await response.json();
      if (json && json.success && json.data) {
        setResult(json.data);
      } else {
        throw new Error(json.error || "Failed to fetch consultation");
      }
    } catch (err: any) {
      console.error("Consultation client error:", err);
      setError("Đã xảy ra lỗi khi kết nối với Cố vấn AI. Đang bật chế độ khôi phục mẫu tư vấn.");
    } finally {
      setIsLoading(false);
    }
  };

  const selectPreset = (text: string) => {
    setPreferences(text);
    handleConsult(text);
  };

  return (
    <div id="sleep-advisor" className="w-full bg-white rounded-3xl border border-stone-200/60 shadow-xl overflow-hidden">
      <div className="bg-eco-sage p-8 md:p-12 text-white relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-2xl -mr-16 -mt-16"></div>
        <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-white/5 rounded-full blur-2xl"></div>

        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-[10px] uppercase tracking-widest font-semibold mb-4 text-eco-beige">
            <Sparkles className="w-3 h-3 text-eco-beige fill-current" /> Cố vấn Sinh thái AI
          </span>
          <h3 className="text-3xl md:text-4xl font-serif mb-4 leading-tight">Chẩn Đoán Sinh Cảnh Giấc Ngủ</h3>
          <p className="text-white/80 font-light text-sm md:text-base leading-relaxed">
            Mỗi con người là một hệ sinh thái riêng biệt. Hãy chia sẻ nỗi khổ, sở thích hay điều kiện khí hậu phòng ngủ của bạn, AI sẽ dệt nên một lộ trình tối ưu về chất liệu và phong cách sống Zen dịu dàng nhất.
          </p>
        </div>
      </div>

      <div className="p-8 md:p-12 grid lg:grid-cols-12 gap-12">
        {/* Inputs */}
        <div className="lg:col-span-5 space-y-6">
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-[0.2em] font-semibold text-eco-charcoal block">Tên của bạn</label>
            <input
              type="text"
              placeholder="Nhập họ tên (không bắt buộc)..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-stone-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-eco-sage focus:ring-1 focus:ring-eco-sage transition duration-200 bg-eco-beige/20 text-eco-charcoal"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-[0.2em] font-semibold text-eco-charcoal block">Sở thích ngủ / Khó chịu hiện tại</label>
            <textarea
              rows={4}
              placeholder="Mô tả cảm thọ vật lý hoặc môi trường phòng ngủ của bạn (ví dụ: 'Nhà tôi ở phố bụi nóng bức, tôi hay bị đổ mồ hôi và thức giấc lúc 3h sáng, thích chăn ga mát rượi làn da...')"
              value={preferences}
              onChange={(e) => setPreferences(e.target.value)}
              className="w-full border border-stone-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-eco-sage focus:ring-1 focus:ring-eco-sage transition duration-200 bg-eco-beige/20 text-eco-charcoal placeholder-stone-400"
            />
          </div>

          {/* Quick presets tags */}
          <div className="space-y-2.5">
            <span className="text-[10px] tracking-wider text-eco-stone uppercase block font-medium">Gợi ý nhanh chủ đề để tư vấn ngay:</span>
            <div className="flex flex-wrap gap-2">
              {presets.map((preset, i) => (
                <button
                  key={i}
                  onClick={() => selectPreset(preset.text)}
                  className="px-3.5 py-1.5 rounded-full border border-stone-200/80 hover:border-eco-sage text-stone-600 hover:text-eco-sage text-xs transition bg-white text-left shadow-sm active:translate-y-[1px] hover:shadow-md cursor-pointer"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-600 leading-relaxed bg-red-50 p-2.5 rounded-lg border border-red-100 font-light">{error}</p>
          )}

          <button
            onClick={() => handleConsult()}
            disabled={isLoading}
            className="w-full bg-eco-charcoal text-white hover:bg-eco-sage disabled:bg-stone-300 py-4 px-6 rounded-full text-xs font-semibold uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-all duration-300 shadow-lg cursor-pointer"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" /> Đang dệt sợi phân tích...
              </>
            ) : (
              <>
                Phân Tích Sinh Cảnh Ngủ <Sparkles className="w-3.5 h-3.5 ml-1 select-none" />
              </>
            )}
          </button>
        </div>

        {/* Output */}
        <div className="lg:col-span-7 flex flex-col justify-center">
          {isLoading && (
            <div className="text-center py-16 space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-eco-beige/65 animate-pulse">
                <Moon className="w-8 h-8 text-eco-sage animate-spin-slow" />
              </div>
              <h5 className="font-serif text-lg text-eco-charcoal italic">"Đang nghe ngóng nhịp đập từ tre lành và tán cọ..."</h5>
              <p className="text-xs text-eco-stone font-light max-w-xs mx-auto leading-relaxed">
                Các thuật toán AI đang ánh xạ các thói quen môi trường của bạn vào dữ liệu các sợi sinh thái cao cấp Everon Eco-Sleep.
              </p>
            </div>
          )}

          {!isLoading && !result && (
            <div className="border border-dashed border-stone-200 rounded-3xl p-12 text-center bg-eco-beige/10 flex flex-col items-center justify-center space-y-4 min-h-[300px]">
              <div className="p-4 rounded-full bg-eco-sage/5 text-eco-sage">
                <Compass className="w-8 h-8 opacity-75" />
              </div>
              <h5 className="font-serif text-xl font-medium text-eco-charcoal text-center">Kết Kết Nối Bản Thể</h5>
              <p className="text-sm text-eco-stone max-w-md mx-auto leading-relaxed font-light">
                Chẩn đoán giấc ngủ nằm gọn ngay tại bước này. Hãy chọn các thẻ khơi gợi phía trái hoặc chủ động nhập tâm sự phòng ngủ của mình để khởi động trạm tư vấn độc quyền.
              </p>
            </div>
          )}

          {!isLoading && result && (
            <div className="p-1 border border-stone-100 rounded-3xl overflow-hidden bg-eco-beige/10 space-y-6">
              {/* Profile Card Header */}
              <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-stone-200/50 space-y-4 relative">
                {result.isDemo && (
                  <span className="absolute top-4 right-4 bg-eco-beige text-eco-stone text-[9px] px-2 py-0.5 rounded uppercase font-bold tracking-wider">
                    Demo Mode
                  </span>
                )}
                
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <span className="text-[9px] font-mono tracking-widest uppercase text-eco-sage font-bold">Chẩn đoán sinh thái của bạn</span>
                    <h4 className="font-serif text-3xl font-bold text-eco-charcoal leading-tight my-1">{result.categoryName}</h4>
                  </div>
                  
                  {/* Circular Match Gauge */}
                  <div className="flex items-center gap-3">
                    <div className="relative w-14 h-14 rounded-full bg-eco-beige flex items-center justify-center">
                      <span className="font-serif text-lg font-bold text-eco-sage">{result.matchPercent}%</span>
                      <svg className="absolute inset-0 w-full h-full -rotate-90">
                        <circle
                          cx="28"
                          cy="28"
                          r="25"
                          fill="transparent"
                          stroke="#EBE5D8"
                          strokeWidth="2.5"
                        />
                        <circle
                          cx="28"
                          cy="28"
                          r="25"
                          fill="transparent"
                          stroke="#5F7161"
                          strokeWidth="2.5"
                          strokeDasharray={`${2 * Math.PI * 25}`}
                          strokeDashoffset={`${2 * Math.PI * 25 * (1 - result.matchPercent / 100)}`}
                        />
                      </svg>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase tracking-wider text-eco-stone font-bold block">Tỉ Lệ</span>
                      <span className="text-xs text-eco-charcoal font-medium">Tương Thích Sinh Cảnh</span>
                    </div>
                  </div>
                </div>

                <div className="h-[1px] bg-stone-100 w-full"></div>

                {/* Fiber suggestions */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white bg-eco-sage px-3 py-1 rounded-full">{result.fabricMatched}</span>
                    <span className="text-xs font-light text-eco-stone">Chất liệu tối ưu nhất</span>
                  </div>
                  <p className="text-sm font-light text-stone-600 leading-relaxed italic">
                    "{result.fabricDescription}"
                  </p>
                </div>
              </div>

              {/* Everon Products Specific suggestions */}
              <div className="p-6 md:p-8 space-y-4">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-eco-sage/10 text-eco-sage">
                    <Bookmark className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] tracking-widest text-eco-stone uppercase block font-bold">Tìm Thiết Kế Everon Phù Hợp:</span>
                    <h5 className="font-serif text-base font-bold text-eco-charcoal mt-0.5">{result.productSuggestion}</h5>
                    <p className="text-xs text-eco-stone font-light leading-relaxed mt-1">
                      Thiết kế hữu cơ nguyên bản giúp làn da được hô hấp tự do, loại bỏ các sợi tổng hợp bám bẩn thông dụng.
                    </p>
                  </div>
                </div>

                {/* Practical tips checklist */}
                <div className="space-y-2 pt-2 border-t border-stone-200/50">
                  <span className="text-[10px] tracking-widest text-eco-stone uppercase block font-bold">3 Lời khuyên cho không gian sinh cảnh:</span>
                  <div className="space-y-2">
                    {result.advice.map((item, index) => (
                      <div key={index} className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-eco-sage mt-0.5 shrink-0" />
                        <p className="text-xs text-stone-600 font-light leading-relaxed">{item}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Zen blessing container */}
                <div className="pt-4 border-t border-stone-200/50 text-center">
                  <p className="text-xs italic text-eco-sage font-medium tracking-wide">
                    "{result.zenBlessing}"
                  </p>
                </div>
                
                {/* Scroll hook to register */}
                <div className="text-right">
                  <a
                    href="#register"
                    className="inline-flex items-center gap-1 text-[11px] uppercase tracking-widest font-bold text-eco-sage hover:text-eco-charcoal transition-colors pt-2 cursor-pointer"
                  >
                    Đăng Ký Nhận Mẫu Thử Vải Này <ChevronRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
export default SleepAdvisor;
