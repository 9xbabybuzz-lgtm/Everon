import { useState, useRef, useEffect } from "react";
import { Volume2, VolumeX, Leaf, CloudRain, Wind, Waves, Play, Pause } from "lucide-react";
import { AmbientLoop } from "../types";

export function AmbientSoundController() {
  const [loops, setLoops] = useState<AmbientLoop[]>([
    { id: "rain", name: "Grass Rain", vietnameseName: "Mưa Thảo Mộc", isPlaying: false, volume: 0.5, type: "rain" },
    { id: "wind", name: "Forest Breeze", vietnameseName: "Gió Cao Nguyên", isPlaying: false, volume: 0.4, type: "wind" },
    { id: "sea", name: "Zen Tide", vietnameseName: "Sóng Âm Thanh", isPlaying: false, volume: 0.3, type: "sea" },
  ]);

  const [masterVolume, setMasterVolume] = useState<number>(0.8);
  const [isAudioInit, setIsAudioInit] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Web Audio Nodes refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseBufferRef = useRef<AudioBuffer | null>(null);

  // Specific sound nodes refs
  const sourcesRef = useRef<{ [key: string]: AudioBufferSourceNode | null }>({
    rain: null,
    wind: null,
    sea: null,
  });

  const gainNodesRef = useRef<{ [key: string]: GainNode | null }>({
    rain: null,
    wind: null,
    sea: null,
  });

  const filterNodesRef = useRef<{ [key: string]: BiquadFilterNode | null }>({
    rain: null,
    wind: null,
    sea: null,
  });

  const lfoRef = useRef<{ [key: string]: OscillatorNode | null }>({
    wind: null,
    sea: null,
  });

  const masterGainRef = useRef<GainNode | null>(null);

  const initAudio = () => {
    if (isAudioInit) return;
    try {
      // Create audio context
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioCtxRef.current = ctx;

      // Master Gain
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(masterVolume, ctx.currentTime);
      masterGain.connect(ctx.destination);
      masterGainRef.current = masterGain;

      // Generate White Noise Buffer (2 seconds)
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      noiseBufferRef.current = noiseBuffer;

      setIsAudioInit(true);
      setErrorMsg(null);
    } catch (err: any) {
      console.error("Failed to initialize Web Audio API:", err);
      setErrorMsg("Trình duyệt hạn chế tự động phát âm thanh. Vui lòng bấm một nút âm thanh để kích hoạt.");
    }
  };

  const startSound = (id: string, type: string, volume: number) => {
    const ctx = audioCtxRef.current;
    const noiseBuffer = noiseBufferRef.current;
    if (!ctx || !noiseBuffer) return;

    // Stop if already running
    stopSound(id);

    // Create Source
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer;
    source.loop = true;

    // Create Gain Node for individual volume
    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(volume, ctx.currentTime);

    // Create Filter Node to sculpt noise
    const filterNode = ctx.createBiquadFilter();

    if (type === "rain") {
      // Rain = Lowpass filter on white noise + dynamic fluctuations
      filterNode.type = "lowpass";
      filterNode.frequency.setValueAtTime(900, ctx.currentTime);
      filterNode.Q.setValueAtTime(1, ctx.currentTime);

      source.connect(filterNode);
      filterNode.connect(gainNode);
    } else if (type === "wind") {
      // Wind = Bandpass filter swept slowly by LFO
      filterNode.type = "bandpass";
      filterNode.frequency.setValueAtTime(450, ctx.currentTime);
      filterNode.Q.setValueAtTime(3.5, ctx.currentTime);

      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.08, ctx.currentTime); // very slow sweep

      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(250, ctx.currentTime); // swept by 250Hz

      lfo.connect(lfoGain);
      lfoGain.connect(filterNode.frequency);
      lfo.start();

      lfoRef.current.wind = lfo;

      source.connect(filterNode);
      filterNode.connect(gainNode);
    } else if (type === "sea") {
      // Sea = Slowly surging tide (modulating gain of a lowpassed noise)
      filterNode.type = "lowpass";
      filterNode.frequency.setValueAtTime(280, ctx.currentTime);

      const lfo = ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.09, ctx.currentTime); // slow sea waves (11s loop)

      const lfoGain = ctx.createGain();
      lfoGain.gain.setValueAtTime(0.12, ctx.currentTime); // modulate volume

      // Bias gain offset so it doesn't fall below silence completely
      const staticGain = ctx.createGain();
      staticGain.gain.setValueAtTime(0.15, ctx.currentTime);

      lfo.connect(lfoGain);
      
      source.connect(filterNode);
      
      // Connect to modulator and to individual node
      filterNode.connect(staticGain);
      staticGain.connect(gainNode);

      // We modulate individual gain manually via interval or LFO if supported
      // To keep it robust, we'll connect LFO to the gain node's gain parameter
      lfoGain.connect(gainNode.gain);
      lfo.start();

      lfoRef.current.sea = lfo;
    }

    // Connect to Master Gain
    if (masterGainRef.current) {
      gainNode.connect(masterGainRef.current);
    }

    source.start(0);

    sourcesRef.current[id] = source;
    gainNodesRef.current[id] = gainNode;
    filterNodesRef.current[id] = filterNode;
  };

  const stopSound = (id: string) => {
    try {
      if (sourcesRef.current[id]) {
        sourcesRef.current[id]?.stop();
        sourcesRef.current[id]?.disconnect();
        sourcesRef.current[id] = null;
      }
      if (gainNodesRef.current[id]) {
        gainNodesRef.current[id]?.disconnect();
        gainNodesRef.current[id] = null;
      }
      if (filterNodesRef.current[id]) {
        filterNodesRef.current[id]?.disconnect();
        filterNodesRef.current[id] = null;
      }
      if (lfoRef.current[id]) {
        lfoRef.current[id]?.stop();
        lfoRef.current[id]?.disconnect();
        lfoRef.current[id] = null;
      }
    } catch (e) {
      console.log("Error cleaning up Web Audio nodes for:", id, e);
    }
  };

  const togglePlay = (id: string) => {
    if (!isAudioInit) {
      initAudio();
    }

    // Since state is asynchronous, we need to handle starting/stopping relative to updated arrays
    setLoops((prev) =>
      prev.map((loop) => {
        if (loop.id === id) {
          const nextPlaying = !loop.isPlaying;
          if (nextPlaying) {
            // Wait slightly for audioCtx to be ready if we just initialized it
            setTimeout(() => {
              // Re-check context state in case of suspended autoplays
              if (audioCtxRef.current && audioCtxRef.current.state === "suspended") {
                audioCtxRef.current.resume();
              }
              startSound(loop.id, loop.type, loop.volume);
            }, 50);
          } else {
            stopSound(loop.id);
          }
          return { ...loop, isPlaying: nextPlaying };
        }
        return loop;
      })
    );
  };

  const handleVolumeChange = (id: string, newVol: number) => {
    setLoops((prev) =>
      prev.map((loop) => {
        if (loop.id === id) {
          if (gainNodesRef.current[id]) {
            // Apply exponential volume curve for more natural acoustics
            gainNodesRef.current[id]!.gain.setValueAtTime(newVol, audioCtxRef.current?.currentTime || 0);
          }
          return { ...loop, volume: newVol };
        }
        return loop;
      })
    );
  };

  // Keep track of master volume changes
  useEffect(() => {
    if (masterGainRef.current && audioCtxRef.current) {
      masterGainRef.current.gain.setValueAtTime(masterVolume, audioCtxRef.current.currentTime);
    }
  }, [masterVolume]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      loops.forEach((loop) => stopSound(loop.id));
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch((err) => console.log("AudioContext close error:", err));
      }
    };
  }, []);

  const getIcon = (type: string) => {
    switch (type) {
      case "rain":
        return <CloudRain className="w-5 h-5 text-eco-sage" />;
      case "wind":
        return <Wind className="w-5 h-5 text-eco-sage" />;
      case "sea":
        return <Waves className="w-5 h-5 text-eco-sage" />;
      default:
        return <Leaf className="w-5 h-5 text-eco-sage" />;
    }
  };

  return (
    <div id="ambient-sounds" className="p-6 md:p-8 rounded-3xl border border-stone-200/60 bg-white shadow-xl max-w-sm w-full">
      <div className="flex items-center justify-between mb-4">
        <div>
          <span className="text-[10px] tracking-widest text-eco-stone uppercase font-bold">Thính Giác</span>
          <h4 className="text-lg font-serif font-medium text-eco-charcoal leading-tight">Âm Thanh Thiên Nhiên</h4>
        </div>
        <button
          onClick={() => {
            initAudio();
            // Toggle master silence
            if (masterVolume > 0) {
              setMasterVolume(0);
            } else {
              setMasterVolume(0.8);
            }
          }}
          className="p-2.5 rounded-full border border-stone-200/50 hover:border-eco-sage text-eco-stone hover:text-eco-sage transition-all"
          title="Tắt/Mở toàn bộ âm thanh"
        >
          {masterVolume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </div>

      {errorMsg && (
        <p className="text-[10px] text-amber-700 bg-amber-50 rounded-lg p-2 mb-4 leading-relaxed font-light">
          {errorMsg}
        </p>
      )}

      {/* sound sliders card */}
      <div className="space-y-4">
        {loops.map((loop) => (
          <div key={loop.id} className="p-3 bg-eco-beige/40 hover:bg-eco-beige/75 rounded-xl border border-stone-100 transition-all flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-lg bg-white shadow-sm border border-stone-100">
                  {getIcon(loop.type)}
                </div>
                <div>
                  <h5 className="font-serif text-sm font-medium text-eco-charcoal">{loop.vietnameseName}</h5>
                  <span className="text-[9px] font-mono text-eco-stone uppercase tracking-wide">{loop.name}</span>
                </div>
              </div>

              <button
                onClick={() => togglePlay(loop.id)}
                className={`p-2 rounded-full cursor-pointer transition-all duration-300 flex items-center justify-center ${
                  loop.isPlaying
                    ? "bg-eco-sage text-white shadow-md hover:bg-eco-charcoal"
                    : "bg-white text-eco-sage border border-stone-200 hover:border-eco-sage"
                }`}
                title={loop.isPlaying ? "Tạm dừng" : "Phát âm thanh"}
              >
                {loop.isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              </button>
            </div>

            {loop.isPlaying && (
              <div className="flex items-center gap-2 mt-1 animate-fade-in">
                <VolumeX className="w-3 h-3 text-eco-stone" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={loop.volume}
                  onChange={(e) => handleVolumeChange(loop.id, parseFloat(e.target.value))}
                  className="w-full h-1 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-eco-sage"
                />
                <Volume2 className="w-3 h-3 text-eco-sage" />
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-stone-100">
        <div className="flex items-center justify-between text-[10px] text-eco-stone">
          <span className="font-light italic">Tạo ra sóng âm học sinh học thư giãn đầu óc</span>
          <span className="font-mono uppercase px-1.5 py-0.5 rounded bg-eco-beige font-semibold">Web Audio Synthesizer</span>
        </div>
      </div>
    </div>
  );
}
