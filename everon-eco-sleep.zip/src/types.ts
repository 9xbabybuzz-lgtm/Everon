export interface ConsultResponse {
  categoryName: string;
  matchPercent: number;
  fabricMatched: string;
  fabricDescription: string;
  productSuggestion: string;
  advice: string[];
  zenBlessing: string;
  isDemo?: boolean;
}

export interface SocialPost {
  id: string;
  author: string;
  avatar: string;
  text: string;
  date: string;
  treesPlanted: number;
  likes: number;
  isUserGenerated?: boolean;
}

export interface AmbientLoop {
  id: string;
  name: string;
  vietnameseName: string;
  isPlaying: boolean;
  volume: number; // 0 to 1
  type: "rain" | "wind" | "sea" | "birds";
}

export interface LeadSubmission {
  name: string;
  contact: string;
  selectedFabric: string;
  mattressPreference: string;
  submitted: boolean;
  voucherCode?: string;
}
