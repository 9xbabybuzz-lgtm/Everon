import React, { useState, useEffect } from "react";
import {
  Leaf,
  Heart,
  Sparkles,
  ChevronRight,
  Share2,
  Lock,
  Gift,
  CheckCircle,
  Menu,
  X,
  Volume2,
  TreePine,
  HelpCircle,
  ChevronDown,
  ArrowRight,
  ClipboardCheck,
  Compass
} from "lucide-react";
import { AmbientSoundController } from "./components/AmbientSoundController";
import { SleepAdvisor } from "./components/SleepAdvisor";
import { SocialPost, LeadSubmission } from "./types";

export default function App() {
  // Mobile nav state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Active Interactive Fabric tab state
  const [selectedFabricTab, setSelectedFabricTab] = useState<string>("tencel");

  // Interactive Tree garden state
  const [totalTrees, setTotalTrees] = useState<number>(1428);
  const [userStory, setUserStory] = useState<string>("");
  const [userAuthor, setUserAuthor] = useState<string>("");
  const [socialFeed, setSocialFeed] = useState<SocialPost[]>([
    {
      id: "p1",
      author: "Nguyễn Thảo Nguyên",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop",
      text: "Vải Tencel từ gỗ bạch đàn của Everon nằm mướt mát dã man mọi người ơi! Giữa trưa hè nóng nực không cần bật điều hòa quá lạnh vẫn ngon ngủ sâu.",
      date: "Vừa xong",
      treesPlanted: 1,
      likes: 24,
    },
    {
      id: "p2",
      author: "Trần Minh Tâm",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop",
      text: "Đã rinh trọn bộ Bamboo thảo mộc về cho bố mẹ. Cụ khen mền êm, thông thoáng khí đỡ đau mỏi gáy hẳn. Ý tưởng một tấm chăn dệt một cây xanh thật tử tế 💚",
      date: "2 giờ trước",
      treesPlanted: 1,
      likes: 42,
    },
    {
      id: "p3",
      author: "Lê Thị Thanh Hà",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
      text: "Trải nghiệm dạo quanh trạm âm thanh thiền ngay trên website cực chill. Thích nhất âm thanh Mưa Thảo Mộc rả rích đưa mình vào giấc ngủ sâu nhanh kinh ngạc.",
      date: "5 giờ trước",
      treesPlanted: 1,
      likes: 19,
    }
  ]);

  // Lead Conversion State
  const [lead, setLead] = useState<LeadSubmission>({
    name: "",
    contact: "",
    selectedFabric: "Tencel Ngọc Lan (Cực kỳ mát mịn)",
    mattressPreference: "Mềm mại, bồng bềnh",
    submitted: false,
    voucherCode: "",
  });

  const [copiedVoucher, setCopiedVoucher] = useState(false);

  // FAQ accordion state
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  // Fabric detailed database
  const fabricDb = {
    tencel: {
      title: "Sợi Tencel Ngọc Lan",
      source: "Gỗ Bạch Đàn và Gỗ Sồi tự nhiên",
      features: ["Lạnh tức thì khi tiếp xúc da", "Thấm hút mồ hôi gấp 1.5 lần cotton", "Phù hợp da siêu nhạy cảm"],
      description: "Thừa hưởng đặc tính của sợi gỗ sồi và bạch đàn tự nhiên siêu mịn bồng bềnh, Tencel đem lại cảm giác 'chạm và mướt sảng khoái'. Tự động hạ nhiệt cơ thể, ngăn ẩm mốc tự nhiên để đem lại giấc ngủ sâu an lành suốt đêm dài hanh khô.",
      image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?q=80&w=1000&auto=format&fit=crop",
    },
    bamboo: {
      title: "Sợi Bamboo Thảo Mộc",
      source: "Xơ Tre non kháng khuẩn thiên nhiên",
      features: ["Khử mùi tự nhiên mạnh mẽ", "Kết cấu xơ rỗng đối lưu gió", "Chống tia cực tím, an lành tuyệt hảo"],
      description: "Giữ trọn đặc tính tự vệ vật lý của cây tre. Thớ sợi rỗng giúp lưu đối không khí lý tưởng, dập tắt các vi khuẩn gây mùi và chống bám bụi bẩn vượt trội cho nhà có em bé nhỏ hoặc người lớn tuổi cần bảo vệ hô hấp.",
      image: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?q=80&w=1000&auto=format&fit=crop",
    },
    modal: {
      title: "Sợi Modal Sương Khuya",
      source: "Cellulose Cây Sồi Châu Âu cổ thụ",
      features: ["Siêu bền bỉ qua hàng trăm lượt giặt", "Độ bóng mượt sang trọng nguyên bản", "Ôm ấp ôm khít từng luồng cơ thể"],
      description: "Dệt từ nguồn cellulose cây sồi quý, thớ vải dai dẻo dính chắc dai sức nhưng mịn màng vô đối. Modal sở hữu độ mềm rũ tự nhiên, ôm khít nâng niu làn da một cách êm ái mà không bao giờ lo xù lông, co rút sụt chỉ.",
      image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?q=80&w=1000&auto=format&fit=crop",
    }
  };

  const handleShareStory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userStory.trim()) return;

    const authorName = userAuthor.trim() || "Người Bạn Môi Trường";
    const newPost: SocialPost = {
      id: "np-" + Date.now(),
      author: authorName,
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop",
      text: userStory,
      date: "Vừa xong",
      treesPlanted: 1,
      likes: 1,
      isUserGenerated: true
    };

    setSocialFeed([newPost, ...socialFeed]);
    setTotalTrees((prev) => prev + 1);
    setUserStory("");
    setUserAuthor("");

    // Light flash effect or auto-scroll can indicate success
    const element = document.getElementById("tree-planting-counter");
    if (element) {
      element.classList.add("scale-110", "bg-eco-sage", "text-white");
      setTimeout(() => {
        element.classList.remove("scale-110", "bg-eco-sage", "text-white");
      }, 1000);
    }
  };

  const handleLeadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead.name.trim() || !lead.contact.trim()) {
      alert("Vui lòng cung cấp phong danh (Họ tên) và cách thức liên lạc (SĐT/Email)");
      return;
    }

    // Generate custom code
    const salt = lead.name.toUpperCase().substring(0, 3).replace(/[^A-Z]/g, "ECO");
    const pin = Math.floor(1000 + Math.random() * 9000);
    const code = `ECO-${salt}-${pin}`;

    setLead({
      ...lead,
      submitted: true,
      voucherCode: code,
    });
  };

  const handleCopyCode = () => {
    if (lead.voucherCode) {
      navigator.clipboard.writeText(lead.voucherCode);
      setCopiedVoucher(true);
      setTimeout(() => setCopiedVoucher(false), 2000);
    }
  };

  // Synchronize dynamic pre-fills from Fabric detail selection to form
  const prefillFabricToForm = (fabricName: string) => {
    setLead((prev) => ({
      ...prev,
      selectedFabric: fabricName,
    }));
    // Scroll smoothly to form
    const elem = document.getElementById("register");
    if (elem) {
      elem.scrollIntoView({ behavior: "smooth" });
    }
  };

  const likePost = (id: string) => {
    setSocialFeed(prev => 
      prev.map(p => p.id === id ? { ...p, likes: p.likes + 1 } : p)
    );
  };

  const faqData = [
    {
      q: "Sợi vải sinh thái Eco-Sleep của Everon khác biệt gì với cotton thông thường?",
      a: "Điểm cốt lõi là nguồn gốc hữu cơ và quy trình sản xuất tuần hoàn khép kín. Ví dụ sợi Tencel dệt bằng cellulose gỗ sồi bạch đàn sử dụng ít hơn 20 lần lượng nước so với trồng cây vải cotton thô, không cần hóa chất phân bón độc hại. Hơn nữa, mặt vải mang cấu trúc lỗ xơ xốp siêu nhỏ, giúp hạ nhiệt sảng khoái vật lý ngay lúc tiếp xúc da dẻ thay vì dồn khí bức bí mồ hôi như sợi thường."
    },
    {
      q: "Chăn ga Everon sinh thái có dễ giặt ủi và bảo quản không?",
      a: "Hoàn toàn dễ dàng! Nhờ cấu trúc công nghệ cao dệt liên kết ma trận xếp chồng, các sợi Modal hay Bamboo dai hơn hẳn so với xơ thô mỏng manh. Bạn có thể giặt máy ở chế độ nhẹ nhàng (giặt len/sợi lụa), tránh chất tẩy mạnh và phơi trong bóng râm lộng gió là chăn đã tơi xốp, giữ vững màu óng thanh thuần."
    },
    {
      q: "Chương trình liên minh gieo hạt '#EveronEcoSleep' hoạt động ra sao?",
      a: "Với khát vọng phủ xanh bạt ngàn Tây Bắc và hạn chế các bãi rác dệt may độc hại, Everon cam kết quy đổi mỗi lượt trải nghiệm thực chất hoặc bài chia sẻ cảm xúc an bình kèm hashtag #EveronEcoSleep thành một mầm cây lim, lát hoa trồng trực tiếp qua Quỹ rừng hữu cơ Everon Việt Nam. Giấc ngủ lành hôm nay gieo bóng mát cho muôn thế hệ mai sau."
    }
  ];

  return (
    <div className="min-h-screen bg-eco-beige text-eco-charcoal font-sans antialiased selection:bg-eco-sage selection:text-white pb-0">
      
      {/* NAVIGATION HEADER */}
      <nav id="navbar" className="fixed top-0 left-0 w-full z-50 transition-all duration-300 border-b border-stone-200/50 glass-card">
        <div className="max-w-7xl mx-auto px-6 py-5 flex justify-between items-center">
          <a href="#" className="flex items-center gap-2 group">
            <Leaf className="w-6 h-6 text-eco-sage group-hover:rotate-12 transition-transform duration-300" />
            <span className="text-xl md:text-2xl font-semibold tracking-[0.25em] font-serif uppercase">
              EVERON
            </span>
          </a>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-10 text-[11px] uppercase tracking-[0.2em] font-bold text-eco-stone">
            <a href="#about" className="hover:text-eco-sage transition-colors duration-200">Trạm Sinh Thái</a>
            <a href="#fabric-selector" className="hover:text-eco-sage transition-colors duration-200">Chất Liệu Xanh</a>
            <a href="#sleep-advisor" className="hover:text-eco-sage transition-colors duration-200">AI Sinh Cảnh</a>
            <a href="#soundscapes" className="hover:text-eco-sage transition-colors duration-200">Thính Giác Zen</a>
            <a href="#tree-garden" className="hover:text-eco-sage transition-colors duration-200">Gieo Mầm Khỏe</a>
            <a href="#faqs" className="hover:text-eco-sage transition-colors duration-200">Giải Đáp</a>
          </div>

          <div className="hidden md:block">
            <a
              href="#register"
              className="bg-eco-sage text-white px-6 py-2.5 rounded-full text-[11px] font-bold uppercase tracking-[0.15em] hover:bg-eco-charcoal transition-all duration-300 shadow-sm"
            >
              Nhận Mẫu Thử
            </a>
          </div>

          {/* Hamburger mobil */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-1.5 rounded bg-white hover:bg-stone-100 border border-stone-200/50 text-eco-charcoal"
            title="Thanh điều hướng"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile menu panel */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-stone-200 animate-slide-down py-6 px-6 space-y-4 shadow-lg">
            <div className="flex flex-col gap-3 font-semibold text-xs tracking-wider uppercase text-eco-stone">
              <a
                href="#about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-1.5 border-b border-stone-100 font-medium active:text-eco-sage"
              >
                Trạm Sinh Thái
              </a>
              <a
                href="#fabric-selector"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-1.5 border-b border-stone-100 font-medium active:text-eco-sage"
              >
                Chất Liệu Xanh
              </a>
              <a
                href="#sleep-advisor"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-1.5 border-b border-stone-100 font-medium active:text-eco-sage"
              >
                AI Sinh Cảnh
              </a>
              <a
                href="#soundscapes"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-1.5 border-b border-stone-100 font-medium active:text-eco-sage"
              >
                Thính Giác Zen
              </a>
              <a
                href="#tree-garden"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-1.5 border-b border-stone-100 font-medium active:text-eco-sage"
              >
                Gieo Mầm Khỏe
              </a>
              <a
                href="#faqs"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-1.5 border-b border-stone-100 font-medium active:text-eco-sage"
              >
                Giải Đáp
              </a>
            </div>
            <a
              href="#register"
              onClick={() => setIsMobileMenuOpen(false)}
              className="inline-block w-full text-center bg-eco-sage text-white py-3 rounded-xl text-xs font-bold uppercase tracking-wider"
            >
              Nhận Voucher 20% & Thử Ga Ga
            </a>
          </div>
        )}
      </nav>

      {/* SECTION 1: HERO BANNER & IMPRESSIONS */}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-32 pb-24 px-6 text-center overflow-hidden">
        {/* Abstract gentle background orbs */}
        <div className="absolute top-24 -left-20 w-80 h-80 bg-eco-sage/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-20 -right-20 w-96 h-96 bg-eco-sage/15 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-4xl z-10 space-y-8">
          <span className="inline-flex items-center gap-2 mb-2 text-[11px] tracking-[0.4em] uppercase text-eco-sage font-bold px-3 py-1 bg-white/60 rounded-full backdrop-blur-sm border border-stone-200/50">
            🌳 Everon Eco-Sleep Collection
          </span>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif mb-8 leading-[1.12] font-light tracking-tight text-eco-charcoal">
            NGUYÊN BẢN VÀ ÊM ÁI – <br />
            <span className="italic text-eco-sage font-normal">Đánh thức giác quan.</span>
          </h1>

          <p className="max-w-2xl mx-auto text-stone-600 text-sm md:text-base font-light leading-relaxed">
            Nơi sợi hữu cơ, nụ mầm sồi và gió mát cao nguyên tụ hội nâng niu cơ thể mệt nhoài. Hãy biến phòng ngủ của bạn thành một Trạm thiên nhiên thu nhỏ để tĩnh lặng và chữa lành thật sự.
          </p>
          
          {/* Main call to Action */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <a
              href="#register"
              className="w-full sm:w-auto bg-eco-sage text-white px-10 py-4.5 rounded-full text-[11px] uppercase tracking-[0.2em] font-semibold hover:bg-eco-charcoal transition-all duration-300 shadow-lg hover:-translate-y-0.5"
            >
              Trải Nghiệm Tinh Tế - Voucher 20%
            </a>
            <a
              href="#sleep-advisor"
              className="w-full sm:w-auto bg-white text-eco-charcoal border border-stone-200 hover:border-eco-sage px-10 py-4.5 rounded-full text-[11px] uppercase tracking-[0.2em] font-semibold transition-all duration-300 shadow-sm hover:shadow-md"
            >
              Hỏi Cố Vấn Giấc Ngủ AI
            </a>
          </div>

          {/* Aesthetic Video Player */}
          <div className="relative w-full max-w-3xl mx-auto mt-16 shadow-2xl rounded-3xl overflow-hidden border-[12px] border-white ring-1 ring-black/5 bg-stone-100">
            <div className="aspect-video bg-stone-200 flex items-center justify-center relative group">
              <iframe
                id="hero-video"
                className="w-full h-full absolute inset-0"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=0&mute=1"
                title="Trình chiếu không gian Everon Eco-Sleep 15s"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
            
            {/* Minimal banner beneath video */}
            <div className="bg-white px-6 py-4 flex flex-col md:flex-row justify-between items-center text-left text-xs text-eco-stone gap-3 border-t border-stone-100">
              <span className="flex items-center gap-1.5 font-light">
                <Leaf className="w-4 h-4 text-eco-sage" /> Sợi sinh thái thô dệt không hóa chất từ thung lũng bảo tồn.
              </span>
              <span className="font-semibold uppercase tracking-wider text-eco-sage">
                Trực quan 15s tinh hoa dệt may
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: STORY & THE THREE PILLARS (FEATURES) */}
      <section id="about" className="py-24 md:py-32 bg-white relative">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
            <span className="text-[10px] tracking-[0.3em] font-bold uppercase text-eco-sage block">Linh Hồn Sản Phẩm</span>
            <h2 className="text-3xl md:text-5xl font-serif text-eco-charcoal">Hành Trình Gieo Nén Bình Yên</h2>
            <p className="text-stone-500 font-light text-sm md:text-base leading-relaxed">
              Chúng tôi không sản xuất gối mền công nghiệp thông thường. Dưới bóng râm của các cánh rừng già sồi bạch đàn cổ thụ, từng rãnh cenlulose được tách chiết sinh học để tạo nên màng bọc thông khí 100% không xơ nhựa tổng hợp.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12 lg:gap-16">
            {/* Phép màu 1 */}
            <div className="group text-center space-y-5 bg-eco-beige/25 p-8 rounded-3xl border border-stone-100 hover:border-eco-sage/20 transition-all duration-300 hover:shadow-md">
              <div className="p-4 bg-white shadow-sm inline-block rounded-2xl text-eco-sage group-hover:scale-105 transition-transform">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 font-light" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
              <h3 className="text-2xl font-serif text-eco-charcoal group-hover:text-eco-sage transition-colors">Hơi thở nguyên bản</h3>
              <p className="text-stone-500 leading-relaxed font-light text-sm">
                Được làm bằng sợi sinh thái 100% tự nhiên phân hủy sinh học tự nhiên, nâng tầm bảo vệ hệ sinh thái trái đất khỏi gánh nặng của vi nhựa tổng hợp.
              </p>
            </div>

            {/* Phép màu 2 */}
            <div className="group text-center space-y-5 bg-eco-beige/25 p-8 rounded-3xl border border-stone-100 hover:border-eco-sage/20 transition-all duration-300 hover:shadow-md">
              <div className="p-4 bg-white shadow-sm inline-block rounded-2xl text-eco-sage group-hover:scale-105 transition-transform">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 font-light" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707" />
                </svg>
              </div>
              <h3 className="text-2xl font-serif text-eco-charcoal group-hover:text-eco-sage transition-colors">Vỗ về xúc giác</h3>
              <p className="text-stone-500 leading-relaxed font-light text-sm">
                Giải tán cái nóng ngột ngạt nhờ khả năng hạ nhiệt cơ thể đối lưu độc nhất. Mịn màng như nước, mền óng xoa dịu triệt để làn da đang bị kích ứng nhạy cảm.
              </p>
            </div>

            {/* Phép màu 3 */}
            <div className="group text-center space-y-5 bg-eco-beige/25 p-8 rounded-3xl border border-stone-100 hover:border-eco-sage/20 transition-all duration-300 hover:shadow-md">
              <div className="p-4 bg-white shadow-sm inline-block rounded-2xl text-eco-sage group-hover:scale-105 transition-transform">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 font-light" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
              </div>
              <h3 className="text-2xl font-serif text-eco-charcoal group-hover:text-eco-sage transition-colors">Ốc đảo tâm hồn</h3>
              <p className="text-stone-500 leading-relaxed font-light text-sm">
                Ý niệm sắp đặt thẩm mỹ thô mộc, tinh khôi. Nơi bạn ngắt kết nối với lo toán để an tâm gác đầu ngủ một giấc thanh hoa thư giãn sâu thẳm.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: INTERACTIVE FABRIC SELECTOR & PREFILL ACCENTS */}
      <section id="fabric-selector" className="py-24 bg-eco-beige relative border-y border-stone-200">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 gap-6">
            <div>
              <span className="text-[10px] tracking-[0.3em] font-bold uppercase text-eco-sage block">Khám phá dệt may</span>
              <h2 className="text-3xl md:text-5xl font-serif mt-2 text-eco-charcoal leading-tight">Mỗi Sợi Sơ, Một Giải Cứu</h2>
            </div>
            <p className="max-w-md text-stone-600 text-xs md:text-sm font-light leading-relaxed">
              Nhấp chọn các chất liệu bên dưới để thấu hiểu đặc tính sinh học của chúng, và chọn đặt làm vỏ mền chính thức nhận voucher ưu dãi độc quyền.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-start">
            {/* Left list options */}
            <div className="lg:col-span-4 flex flex-col gap-3">
              <button
                onClick={() => setSelectedFabricTab("tencel")}
                className={`w-full p-6 rounded-2xl border text-left transition-all duration-300 flex items-center justify-between cursor-pointer ${
                  selectedFabricTab === "tencel"
                    ? "bg-white border-eco-sage shadow-md"
                    : "bg-white/40 border-stone-200 hover:border-eco-sage/55 hover:bg-white"
                }`}
              >
                <div>
                  <h4 className="font-serif text-lg font-bold">Tencel Bạch Đàn</h4>
                  <span className="text-[10px] text-eco-stone uppercase tracking-widest font-mono">Cực kỳ dịu mát</span>
                </div>
                <ArrowRight className={`w-4 h-4 transition-transform ${selectedFabricTab === "tencel" ? "translate-x-1 text-eco-sage" : "text-stone-300"}`} />
              </button>

              <button
                onClick={() => setSelectedFabricTab("bamboo")}
                className={`w-full p-6 rounded-2xl border text-left transition-all duration-300 flex items-center justify-between cursor-pointer ${
                  selectedFabricTab === "bamboo"
                    ? "bg-white border-eco-sage shadow-md"
                    : "bg-white/40 border-stone-200 hover:border-eco-sage/55 hover:bg-white"
                }`}
              >
                <div>
                  <h4 className="font-serif text-lg font-bold">Bamboo Thảo Mộc</h4>
                  <span className="text-[10px] text-eco-stone uppercase tracking-widest font-mono">Kháng khuẩn, tự nhiên</span>
                </div>
                <ArrowRight className={`w-4 h-4 transition-transform ${selectedFabricTab === "bamboo" ? "translate-x-1 text-eco-sage" : "text-stone-300"}`} />
              </button>

              <button
                onClick={() => setSelectedFabricTab("modal")}
                className={`w-full p-6 rounded-2xl border text-left transition-all duration-300 flex items-center justify-between cursor-pointer ${
                  selectedFabricTab === "modal"
                    ? "bg-white border-eco-sage shadow-md"
                    : "bg-white/40 border-stone-200 hover:border-eco-sage/55 hover:bg-white"
                }`}
              >
                <div>
                  <h4 className="font-serif text-lg font-bold">Modal Sương Khuya</h4>
                  <span className="text-[10px] text-eco-stone uppercase tracking-widest font-mono">Căng bóng vững chãi</span>
                </div>
                <ArrowRight className={`w-4 h-4 transition-transform ${selectedFabricTab === "modal" ? "translate-x-1 text-eco-sage" : "text-stone-300"}`} />
              </button>
            </div>

            {/* Right Display area */}
            <div className="lg:col-span-8 bg-white border border-stone-200/50 rounded-3xl p-6 md:p-10 shadow-xl grid md:grid-cols-12 gap-8">
              {/* Product text details */}
              <div className="md:col-span-7 flex flex-col justify-between space-y-6">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-eco-sage block font-bold">
                    Nguồn gốc: {fabricDb[selectedFabricTab as keyof typeof fabricDb].source}
                  </span>
                  <h3 className="font-serif text-2xl md:text-3xl font-semibold mt-1 text-eco-charcoal">
                    {fabricDb[selectedFabricTab as keyof typeof fabricDb].title}
                  </h3>
                  <p className="text-stone-600 text-xs md:text-sm font-light leading-relaxed mt-4">
                    {fabricDb[selectedFabricTab as keyof typeof fabricDb].description}
                  </p>
                </div>

                <div className="space-y-3">
                  <span className="text-[9px] uppercase tracking-widest text-eco-stone block font-bold">Đặc Điểm Sinh Học Vượt Trội:</span>
                  <div className="space-y-2">
                    {fabricDb[selectedFabricTab as keyof typeof fabricDb].features.map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-eco-sage shrink-0" />
                        <span className="text-xs text-eco-charcoal font-medium font-sans">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-100 flex items-center justify-between gap-4">
                  <div>
                    <span className="text-[9px] text-eco-stone block uppercase font-bold">Mẫu thử ga dệt sẵn</span>
                    <span className="text-xs text-eco-charcoal">Hộp 1 mẫu thử sợi bọc lót</span>
                  </div>
                  <button
                    onClick={() => prefillFabricToForm(fabricDb[selectedFabricTab as keyof typeof fabricDb].title)}
                    className="bg-eco-sage hover:bg-eco-charcoal text-white text-[11px] font-bold uppercase tracking-[0.1em] px-5 py-3 rounded-lg transition-colors cursor-pointer"
                  >
                    Chọn Thử Sợi Này
                  </button>
                </div>
              </div>

              {/* Photo representation */}
              <div className="md:col-span-5 relative rounded-2xl overflow-hidden aspect-square md:aspect-auto md:h-full bg-stone-100 min-h-[220px]">
                <img
                  src={fabricDb[selectedFabricTab as keyof typeof fabricDb].image}
                  className="absolute inset-0 w-full h-full object-cover shadow-inner transition-transform duration-700 hover:scale-105"
                  alt={fabricDb[selectedFabricTab as keyof typeof fabricDb].title}
                />
                <div className="absolute top-3 left-3 bg-white/80 backdrop-blur px-2.5 py-1 rounded text-[10px] tracking-widest uppercase font-bold text-eco-sage">
                  Dệt hữu cơ sạch
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: AI SLEEP ADVISOR (Embedded interactive) */}
      <section className="py-24 md:py-32 bg-white relative">
        <div className="max-w-6xl mx-auto px-6">
          <SleepAdvisor />
        </div>
      </section>

      {/* SECTION 5: TRẠM THÍNH GIÁC RELAXATION DYNAMIC SOUNDSCAPES */}
      <section id="soundscapes" className="py-24 bg-eco-beige relative border-t border-stone-200">
        {/* Abstract design elements */}
        <div className="absolute top-1/2 left-12 w-64 h-64 bg-eco-sage/5 rounded-full blur-2xl pointer-events-none"></div>

        <div className="max-w-6xl mx-auto px-6 grid lg:grid-cols-12 gap-12 items-center">
          {/* Side title */}
          <div className="lg:col-span-7 space-y-6">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-eco-sage/10 text-eco-sage text-[10px] uppercase tracking-widest font-bold">
              <Volume2 className="w-3.5 h-3.5" /> Liệu pháp Thính Giác sinh học
            </span>
            <h2 className="text-3xl md:text-5xl font-serif text-eco-charcoal leading-tight">
              Lọc Sạch Ồn Ả, <br />
              Nghe Thảo Mộc Rì Rầm
            </h2>
            <p className="text-stone-600 text-sm md:text-base font-light leading-relaxed">
              Trình duyệt của bạn sẽ biến thành một bộ mô phỏng tần số chữa lành của cỏ dại Tây Bắc. Sử dụng bộ trộn âm lượng (dựa trên Web Audio API tổng hợp trực tiếp), bạn có thể xếp chồng tiếng mưa thảo mộc mềm rụng hoặc gió cao nguyên rì rầm theo ý thích để thư thái óc não ngủ một giấc vẹn nguyên.
            </p>
            <div className="p-4 bg-white/60 border border-stone-200/50 rounded-2xl flex items-center gap-3 max-w-md">
              <Compass className="w-5 h-5 text-eco-sage shrink-0" />
              <p className="text-xs text-eco-stone font-light">
                <strong>Gợi ý thiền:</strong> Bật sừng sững tiếng Gió Cao Nguyên ở mức 30%, kèm theo Mưa Thảo Mộc rả rích 60% để giải tỏa dứt điểm mệt mỏi trong 10 phút.
              </p>
            </div>
          </div>

          {/* sound widget */}
          <div className="lg:col-span-5 flex justify-center">
            <AmbientSoundController />
          </div>
        </div>
      </section>

      {/* SECTION 6: INTERACTIVE TREE GARDEN & FOREST COMMUNITY SOCIALS */}
      <section id="tree-garden" className="py-24 md:py-32 bg-white relative overflow-hidden text-center">
        <div className="absolute top-10 right-10 w-48 h-48 bg-emerald-50 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="max-w-4xl mx-auto px-6 space-y-8">
          <span className="text-[10px] tracking-[0.3em] font-bold uppercase text-eco-sage block">Ý tưởng nhân văn</span>
          <h2 className="text-3xl md:text-5xl font-serif text-eco-charcoal leading-tight">Một Tấm Chăn, Một Mầm Xanh</h2>
          
          <p className="max-w-2xl mx-auto text-stone-500 font-light text-sm md:text-base leading-relaxed">
            Chúng tôi không chỉ chăm nom giấc ngủ của bạn, mà còn gánh vác tương lai của rừng lim hoang dã Tây Bắc. Mỗi câu kinh nghiệm bình an bạn chia sẻ kèm hashtag <span className="font-bold text-eco-charcoal">#EveronEcoSleep</span> sẽ thúc đẩy chúng tôi thay bạn gieo trồng thêm một cây tươi tốt.
          </p>

          {/* Dynamic visual counter card */}
          <div id="tree-planting-counter" className="inline-flex flex-col md:flex-row items-center gap-6 bg-eco-beige/65 border border-stone-200/60 shadow-md p-6 md:px-12 md:py-6 rounded-3xl transition-all duration-700">
            <div className="p-3.5 rounded-2xl bg-white shadow-sm text-eco-sage">
              <TreePine className="w-8 h-8" />
            </div>
            <div className="text-left space-y-1">
              <span className="text-[10px] uppercase font-mono tracking-widest text-eco-stone font-bold">Mầm xanh hữu cơ đã vào đất:</span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl md:text-4xl font-serif font-black text-eco-sage">{totalTrees}</span>
                <span className="text-xs text-eco-charcoal font-semibold">Cánh Thư Gieo Trồng</span>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-start pt-10 text-left">
            {/* Input Form Share block */}
            <div className="lg:col-span-5 bg-eco-beige/30 p-6 md:p-8 rounded-3xl border border-stone-100 shadow-inner space-y-4">
              <h4 className="font-serif text-lg font-bold">Chia Sẻ Giấc Mộng Lành</h4>
              <p className="text-xs text-eco-stone font-light leading-relaxed">
                Khi đăng chia sẻ bên dưới, mầm xanh gỗ quý tại vườn trồng Everon Hoà Bình sẽ chính thức gán tên bạn và tổng đài cây xanh cộng đồng sẽ tự động tăng lên!
              </p>

              <form onSubmit={handleShareStory} className="space-y-4 pt-2">
                <div>
                  <input
                    type="text"
                    required
                    placeholder="Biệt danh hoặc phong danh của bạn..."
                    value={userAuthor}
                    onChange={(e) => setUserAuthor(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl px-4 py-2.5 text-xs focus:ring-1 focus:ring-eco-sage focus:outline-none"
                  />
                </div>
                <div>
                  <textarea
                    rows={4}
                    required
                    maxLength={300}
                    placeholder="Mô tả sự nhẹ nhõm, thảnh thơi mà bạn có được khi rũ bỏ lo toán mệt nhoài (ví dụ: 'Yêu cái trong lành của gió mơn, giấc nồng sâu dạt dào bọt tre...')"
                    value={userStory}
                    onChange={(e) => setUserStory(e.target.value)}
                    className="w-full bg-white border border-stone-200 rounded-xl p-4 text-xs focus:ring-1 focus:ring-eco-sage focus:outline-none"
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-eco-sage hover:bg-eco-charcoal text-white text-[11px] font-bold uppercase tracking-widest py-3 rounded-full transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow"
                >
                  Gieo Trồng & Đăng Đàn <Leaf className="w-3.5 h-3.5 fill-current" />
                </button>
              </form>
            </div>

            {/* Live Feed list */}
            <div className="lg:col-span-7 space-y-4 max-h-[460px] overflow-y-auto pr-1">
              {socialFeed.map((post) => (
                <div key={post.id} className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm space-y-3 hover:shadow-md transition">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <img src={post.avatar} className="w-8 h-8 rounded-full object-cover shrink-0" alt={post.author} />
                      <div>
                        <h5 className="text-xs font-bold text-eco-charcoal">{post.author}</h5>
                        <span className="text-[9px] text-eco-stone">{post.date}</span>
                      </div>
                    </div>
                    
                    {/* tree badge generated representatively */}
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-50 text-[10px] text-emerald-800 font-bold border border-emerald-100">
                      <TreePine className="w-3 h-3 text-emerald-600" /> +1 Cây Đã Gieo Trồng
                    </span>
                  </div>
                  
                  <p className="text-xs text-eco-charcoal font-light leading-relaxed">
                    {post.text}
                  </p>

                  <div className="flex items-center gap-4 pt-1.5 text-[10px] text-eco-stone">
                    <button
                      onClick={() => likePost(post.id)}
                      className="flex items-center gap-1 hover:text-red-500 transition cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5 text-red-500 fill-current" /> Thích ({post.likes})
                    </button>
                    <span className="text-stone-300">|</span>
                    <span className="font-mono">#EveronEcoSleep</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 7: CONVERSION FORM (VOUCHER GENERATION) */}
      <section id="register" className="py-24 md:py-32 bg-eco-beige relative border-y border-stone-250">
        <div className="max-w-4xl mx-auto px-6">
          <div className="bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row border border-stone-200/50">
            {/* Form decorative media banner */}
            <div className="md:w-5/12 bg-eco-sage/20 relative min-h-[300px] md:min-h-auto">
              <img
                src="https://images.unsplash.com/photo-1520333781090-e2ad16bc8e91?q=80&w=2070&auto=format&fit=crop"
                className="absolute inset-0 w-full h-full object-cover mix-blend-multiply opacity-50"
                alt="Everon Eco-Sleep mộc mạc"
              />
              <div className="absolute inset-0 p-8 flex flex-col justify-between text-white z-10 bg-gradient-to-t from-black/50 via-transparent to-black/10">
                <span className="inline-block self-start text-[9px] uppercase tracking-widest bg-white/20 backdrop-blur-sm px-2 py-0.5 rounded-full">
                  Mẫu Thử Thật - Thổi Ngay Giấc Đẹp
                </span>
                
                <div>
                  <p className="font-serif text-2xl italic leading-snug">"Thiên nhiên vỗ về giấc ngủ sâu."</p>
                  <p className="text-[10px] font-sans font-light mt-1 text-white/80">Bộ mẫu thử xúc giác dệt chứa sợi tơ Modal & Bamboo sồi tự nhiên.</p>
                </div>
              </div>
            </div>

            {/* Form container */}
            <div className="md:w-7/12 p-8 md:p-12">
              {!lead.submitted ? (
                <div className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-serif text-eco-charcoal uppercase tracking-normal">Chạm Để Thấu Hiểu</h2>
                    <p className="text-stone-400 text-xs mt-1.5 font-light italic">
                      Đăng ký nhận miễn phí mẫu thử vải sinh thái Everon tận nhà và nhận code giảm giá 20% độc quyền áp dụng toàn bộ hệ thống showroom.
                    </p>
                  </div>

                  <form onSubmit={handleLeadSubmit} className="space-y-5">
                    {/* Name */}
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider text-eco-stone font-bold block">Danh tính của bạn (Họ và Tên)</label>
                      <input
                        type="text"
                        required
                        value={lead.name}
                        onChange={(e) => setLead({ ...lead, name: e.target.value })}
                        placeholder="Nguyễn Văn A..."
                        className="w-full border-b border-stone-250 py-2 text-sm focus:outline-none focus:border-eco-sage bg-transparent transition text-eco-charcoal"
                      />
                    </div>

                    {/* Contact */}
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase tracking-wider text-eco-stone font-bold block">Cách Thức Liên Lạc (SĐT / Email)</label>
                      <input
                        type="text"
                        required
                        value={lead.contact}
                        onChange={(e) => setLead({ ...lead, contact: e.target.value })}
                        placeholder="Số điện thoại hoặc Email để gửi bưu phẩm..."
                        className="w-full border-b border-stone-250 py-2 text-sm focus:outline-none focus:border-eco-sage bg-transparent transition text-eco-charcoal"
                      />
                    </div>

                    {/* Micro preference selectors configurer */}
                    <div className="grid grid-cols-2 gap-4 pt-1">
                      <div className="space-y-1.5">
                        <label className="text-[9px] uppercase tracking-wider text-eco-stone font-bold block">Sợi vải đặc biệt muốn thử:</label>
                        <select
                          value={lead.selectedFabric}
                          onChange={(e) => setLead({ ...lead, selectedFabric: e.target.value })}
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-eco-sage"
                        >
                          <option>Tencel Ngọc Lan (Cực kỳ mát mịn)</option>
                          <option>Bamboo Thảo Mộc (Kháng khuẩn bảo vệ)</option>
                          <option>Modal Sương Khuya (Căng bóng dẻo dai)</option>
                          <option>Organic Cotton (Tự nhiên thô thuần)</option>
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[9px] uppercase tracking-wider text-eco-stone font-bold block">Độ sụn nún mong mỏi:</label>
                        <select
                          value={lead.mattressPreference}
                          onChange={(e) => setLead({ ...lead, mattressPreference: e.target.value })}
                          className="w-full bg-white border border-stone-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-eco-sage"
                        >
                          <option>Mềm mại, bồng bềnh như mây</option>
                          <option>Nâng đỡ tối ưu, giảm mệt nhừ</option>
                          <option>Nệm cứng thô mộc, mát lưng khí</option>
                        </select>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full bg-eco-sage text-white py-4 rounded-full text-[10px] font-bold uppercase tracking-[0.25em] hover:bg-eco-charcoal transition-all shadow-lg hover:shadow-xl cursor-pointer"
                      >
                        Gửi Tôi Ưu Đãi & Mẫu Vải Ngay
                      </button>
                    </div>

                    <div className="flex justify-center items-center gap-1 text-[9px] text-eco-stone">
                      <Lock className="w-3 h-3 text-stone-400" />
                      <span>Cam kết bảo mật thông tin gieo mầm sống lành theo tiêu chuẩn Everon.</span>
                    </div>
                  </form>
                </div>
              ) : (
                <div className="space-y-6 text-center py-6 animate-fade-in">
                  <div className="w-16 h-16 rounded-full bg-emerald-50 text-eco-sage flex items-center justify-center mx-auto border border-emerald-100 shadow-sm">
                    <Gift className="w-8 h-8" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-serif text-3xl font-bold text-eco-charcoal">Chào mừng đến với Liên Minh Xanh!</h3>
                    <p className="text-stone-500 font-light text-xs max-w-md mx-auto leading-relaxed">
                      Sự lựa chọn tử tế của <strong>{lead.name}</strong> đã được lưu trữ thành công. Gói xúc giác mẫu gồm dạng sợi <strong>{lead.selectedFabric}</strong> sẽ được vận chuyển tới <strong>{lead.contact}</strong> trong 3 ngày tới!
                    </p>
                  </div>

                  {/* Coupon layout */}
                  <div className="bg-eco-beige/60 p-6 rounded-2xl border border-dashed border-eco-sage/50 max-w-sm mx-auto space-y-3 relative overflow-hidden">
                    {/* Left right ticket holes */}
                    <div className="absolute top-1/2 -left-3 w-6 h-6 bg-white rounded-full -translate-y-1/2"></div>
                    <div className="absolute top-1/2 -right-3 w-6 h-6 bg-white rounded-full -translate-y-1/2"></div>

                    <span className="text-[9px] font-mono tracking-widest text-eco-stone uppercase block font-bold">MÃ ƯU ĐÃI ĐỘC QUYỀN 20%:</span>
                    <div className="font-serif text-2xl font-black text-eco-charcoal tracking-widest">{lead.voucherCode}</div>
                    
                    <button
                      onClick={handleCopyCode}
                      className="inline-flex items-center gap-1 px-4 py-1.5 rounded bg-white hover:bg-stone-100 border border-stone-200 text-xs text-eco-charcoal font-medium shadow-sm transition active:scale-95 cursor-pointer"
                    >
                      {copiedVoucher ? (
                        <>
                          Đã Sao Chép <ClipboardCheck className="w-3.5 h-3.5 text-emerald-600" />
                        </>
                      ) : (
                        <>
                          Sao Chép Mã Ưu Đãi
                        </>
                      )}
                    </button>
                  </div>

                  <p className="text-[10px] text-eco-stone leading-relaxed">
                    *Áp dụng quy đổi trực tiếp giảm 20% khi rinh bộ chăn ga gối nệm Everon Eco-Sleep mới nhất tại mọi phòng trải nghiệm toàn quốc.
                  </p>

                  <button
                    onClick={() => setLead({ ...lead, submitted: false })}
                    className="text-xs text-eco-stone hover:text-eco-sage underline cursor-pointer"
                  >
                    Đăng ký cho người thân khác
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 8: FAQA & QUESTIONS GUIDE */}
      <section id="faqs" className="py-24 bg-white relative">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center space-y-3 mb-16">
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-eco-sage block">Giải Đáp Thắc Mắc</span>
            <h2 className="text-3xl md:text-5xl font-serif text-eco-charcoal">Hỏi đáp về dệt may hữu cơ</h2>
            <p className="text-stone-500 font-light text-sm max-w-lg mx-auto">
              Cùng kiến tạo không gian ngủ thông dưỡng khí lành mạnh lý tưởng qua các câu hỏi thông dụng bên dưới.
            </p>
          </div>

          <div className="space-y-4">
            {faqData.map((item, idx) => (
              <div
                key={idx}
                className="p-5 md:p-6 rounded-2xl border border-stone-200/60 bg-eco-beige/10 hover:bg-eco-beige/30 transition-all duration-300"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                  className="w-full flex items-center justify-between text-left font-serif text-base md:text-lg font-bold text-eco-charcoal focus:outline-none cursor-pointer"
                >
                  <span>{item.q}</span>
                  <ChevronDown className={`w-4 h-4 text-eco-stone shrink-0 transition-transform duration-300 ${activeFaq === idx ? "rotate-180 text-eco-sage" : ""}`} />
                </button>
                
                {activeFaq === idx && (
                  <p className="mt-4 text-xs md:text-sm text-stone-600 font-light leading-relaxed border-t border-stone-200/50 pt-4 animate-fade-in">
                    {item.a}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-16 bg-eco-charcoal text-stone-300 relative overflow-hidden">
        <div className="absolute -top-12 -left-12 w-48 h-48 bg-white/5 rounded-full blur-2xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-12 gap-12 text-left border-b border-stone-800 pb-12">
          {/* logo column */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <Leaf className="w-5 h-5 text-eco-sage" />
              <span className="text-lg font-serif font-semibold tracking-[0.2em] text-white">EVERON</span>
            </div>
            <p className="text-xs text-stone-400 font-light leading-relaxed max-w-sm">
              Thương hiệu chăn ga gối đệm thân thiện bậc nhất phục vụ giấc ngủ vàng suốt 2 thập kỷ của hàng triệu gia đình Việt Nam. Đồng hành cùng liên minh thiên nhiên bảo vệ mầm cây bản địa.
            </p>
          </div>

          {/* links 1 */}
          <div className="md:col-span-4 space-y-4">
            <h5 className="text-[10px] tracking-[0.25em] uppercase text-white font-bold">Chất Liệu Nguyên Bản</h5>
            <ul className="text-xs text-stone-400 font-light space-y-2">
              <li>- Vải gỗ Bạch đàn Ngọc lan (Mát sâu)</li>
              <li>- Vải xơ tre Bamboo non (Tự đề kháng)</li>
              <li>- Vải gỗ sồi quý Modal (Dẻo tơi óng mượt)</li>
              <li>- Cao su thiên nhiên nâng đỡ cột sống</li>
            </ul>
          </div>

          {/* links 2 contact info */}
          <div className="md:col-span-4 space-y-4">
            <h5 className="text-[10px] tracking-[0.25em] uppercase text-white font-bold">Trạm Thiên Nhiên Everon</h5>
            <div className="text-xs text-stone-400 font-light space-y-2">
              <p>📍 Showroom trưng bày chẩn đoán giấc ngủ sinh cảnh tại Hà Nội, Đà Nẵng, TP. Hồ Chí Minh.</p>
              <p>📞 Tổng đài trợ lý sinh cảnh 1800 6000 (Miễn phí)</p>
              <p>✉️ lienhe@everon-ecosleep.vn</p>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-6 pt-8 flex flex-col md:flex-row justify-between items-center text-[10px] text-stone-500 gap-4">
          <p className="uppercase tracking-[0.3em]">&copy; 2026 EVERON VIETNAM. MANG THIÊN NHIÊN VÀO GIẤC NGỦ SÂU.</p>
          <div className="flex gap-4">
            <span className="hover:text-stone-300 cursor-pointer">Chính sách bảo mật</span>
            <span>|</span>
            <span className="hover:text-stone-300 cursor-pointer">Quy chế gieo mầm lim quý</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
