import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client safely
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
} else {
  console.warn("GEMINI_API_KEY is not defined in environment variables. Running in demo mode for consulting.");
}

// REST API for consulting sleep profiles
app.post("/api/consult", async (req, res) => {
  const { preferences, name } = req.body;
  const safeName = name ? name.trim() : "Quý khách";

  if (!preferences || preferences.trim() === "") {
    return res.status(400).json({ error: "Preferences are required." });
  }

  // Backup fallback template in case Gemini fails or API key is not present
  const generateFallback = () => {
    const fabrics = [
      {
        categoryName: "Nhóm Rừng Sương Ban Mai",
        matchPercent: 95,
        fabricMatched: "Tencel (Sợi gỗ bạch đàn tự nhiên)",
        fabricDescription: "Loại vải siêu mịn mát từ gỗ cây sồi và bạch đàn, có khả năng hạ nhiệt tự nhiên tức thì khi chạm vào, thấm hút mồ hôi ưu việt lý tưởng cho làn da nhạy cảm.",
        productSuggestion: "Bộ chăn ga Everon Tencel Ngọc Lan",
        advice: [
          "Hãy duy trì nhiệt độ phòng ngủ ở mức lý tưởng 24-26 độ C.",
          "Hãy tắt toàn bộ màn hình xanh 30 phút trước khi ngả lưng.",
          "Thử đặt một nhánh oải hương khô bên dưới gối ngủ."
        ],
        zenBlessing: "Nguyện cho làn gió nhẹ của đêm lành xoa dịu đôi mi mỏi mệt."
      },
      {
        categoryName: "Nhóm Gió Cát Ấm Áp",
        matchPercent: 92,
        fabricMatched: "Bamboo (Sợi tre kháng khuẩn)",
        fabricDescription: "Cấu trúc xơ tre rỗng tự nhiên giúp điều hòa nhiệt đối lưu siêu tốt, khả năng kháng khuẩn tự nhiên cao, chống nấm mốc tuyệt vời cho khí hậu nóng ẩm.",
        productSuggestion: "Bộ ga chun Everon Bamboo Thảo Mộc",
        advice: [
          "Dùng gối có chiều cao lý tưởng khoảng 8-12cm nâng đỡ đốt sống cổ.",
          "Tắm nước ấm trước khi đi ngủ khoảng 1 tiếng.",
          "Thực hành hơi thở 4-7-8 để điều hòa nhịp tim."
        ],
        zenBlessing: "Như thân tre dẻo dai đón gió mát, lòng ta nhẹ nhõm thảnh thơi trôi."
      },
      {
        categoryName: "Nhóm Thung Lũng Tĩnh Lặng",
        matchPercent: 96,
        fabricMatched: "Modal (Sợi cenlulose gỗ sồi)",
        fabricDescription: "Vải dệt từ cellulose cây sồi Châu Âu, chịu lực co giãn cực tốt và giữ độ mềm tơi óng ả tuyệt vời dù trải qua nhiều lần giặt, êm dịu bảo vệ làn da mỏng manh.",
        productSuggestion: "Bộ Everon Modal Sương Khuya",
        advice: [
          "Giữ phòng ngủ tối hoàn toàn để tối ưu hóc-môn melatonin.",
          "Mở một tiếng chuông thiền nhỏ không lời trong 10 phút đầu ngủ.",
          "Chăn đắp vừa vặn ôm cơ thể cho giấc ngủ sâu thêm vững vàng."
        ],
        zenBlessing: "Bỏ lại ngàn vạn lo âu ngoài ngưỡng cửa, đêm nay ta ngủ một giấc thanh thuần."
      }
    ];

    // Pick one randomly or based on preferences string length
    const idx = preferences.length % fabrics.length;
    return fabrics[idx];
  };

  if (!ai) {
    // Return fallback directly is no AI Client is configured
    return res.json({
      success: true,
      data: {
        ...generateFallback(),
        isDemo: true
      }
    });
  }

  try {
    const prompt = `Bạn là chuyên gia cố vấn giấc ngủ sinh thái của Everon Vietnam cho dòng sản phẩm "Everon Eco-Sleep".
Khách hàng tên là: ${safeName}.
Hãy phân tích đặc điểm giấc ngủ, sự khó chịu / thói quen ngủ sau đây:
"${preferences}"

Hãy tư vấn giấc ngủ và đưa ra giải pháp chăm sóc cho họ. Phân loại họ vào một nhóm phong cách sống Zen dịu mát, chọn một chất liệu vải sinh thái phù hợp nhất (Bamboo - Sợi tre, Tencel - Sồi/bạch đàn, Modal - Sồi Châu Âu, hoặc Organic Cotton) lý giải tại sao chất liệu này cứu rỗi nỗi khổ của họ, đề xuất một sản phẩm chăn ga Everon Eco-Sleep cụ thể và cho lời khuyên.

Bạn bắt buộc phải trả về duy nhất định dạng JSON có cấu trúc chính xác sau:
{
  "categoryName": "Tên nhóm giấc ngủ thiên nhiên mang đậm phong cách Zen thi ca bằng tiếng Việt (ví dụ: 'Nhóm Rừng Sương Ban Mai' hoặc 'Nhóm Thung Lũng Trúc Xanh')",
  "matchPercent": 95 (một số nguyên thể hiện tỉ lệ tương thích từ 85 đến 99),
  "fabricMatched": "Tên loại chất liệu vải phù hợp nhất",
  "fabricDescription": "Lý giải ngắn gọn tại sao chất liệu sinh thái này giải quyết triệt để nỗi khổ của họ",
  "productSuggestion": "Tên sản phẩm Everon Eco-Sleep đề xuất cao cấp",
  "advice": [
    "Lời khuyên 1 thực tế về thói quen ngủ",
    "Lời khuyên 2 thực tế về thói quen ngủ",
    "Lời khuyên 3 thực tế về thói quen ngủ"
  ],
  "zenBlessing": "Một câu chúc thiền (Zen blessing) tối giản, dịu dàng, thơ mộng bằng tiếng Việt mang tính nâng đỡ tinh thần và vỗ về giấc ngủ sâu."
}

Yêu cầu: Chỉ trả về JSON thuần túy, tuyệt đối không bao bọc bởi tag markdown hay bất kỳ ký tự dư thừa nào. Hãy phản hồi bằng tiếng Việt.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            categoryName: { type: Type.STRING },
            matchPercent: { type: Type.INTEGER },
            fabricMatched: { type: Type.STRING },
            fabricDescription: { type: Type.STRING },
            productSuggestion: { type: Type.STRING },
            advice: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            zenBlessing: { type: Type.STRING }
          },
          required: ["categoryName", "matchPercent", "fabricMatched", "fabricDescription", "productSuggestion", "advice", "zenBlessing"]
        }
      }
    });

    const text = response.text;
    if (text) {
      try {
        const parsedData = JSON.parse(text.trim());
        return res.json({
          success: true,
          data: parsedData
        });
      } catch (jsonErr) {
        console.error("Failed to parse AI output as JSON:", text, jsonErr);
        // Fallback to beautiful default
        return res.json({
          success: true,
          data: generateFallback(),
          isDemo: true
        });
      }
    } else {
      throw new Error("No response text from Gemini");
    }
  } catch (err: any) {
    console.error("Gemini API consultation error:", err);
    return res.json({
      success: true,
      data: generateFallback(),
      isDemo: true,
      errorDetails: err.message || "Unknown error"
    });
  }
});

// Start routing static or integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Everon Eco-Sleep server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
